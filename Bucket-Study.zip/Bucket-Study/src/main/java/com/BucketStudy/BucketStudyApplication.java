package com.BucketStudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BucketStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BucketStudyApplication.class, args);
	}

}
