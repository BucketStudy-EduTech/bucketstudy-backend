//package com.BucketStudy.Dto;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//@Setter
//@Getter
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class LoginRequestDto {
//    private String username;
//    private String password;
//	public Object getUsername() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	public Object getPassword() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//}
