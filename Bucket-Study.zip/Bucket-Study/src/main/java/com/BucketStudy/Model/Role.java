package com.BucketStudy.Model;

public enum Role {
    STUDENT, ADMIN, INSTRUCTOR
}
